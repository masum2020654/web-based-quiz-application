<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact - QuizApp</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'navbar.php'; ?>
<section class="content">
    <h2>Contact Us</h2>
    <p>For feedback or support, email us at <a href="mailto:support@quizapp.com">support@quizapp.com</a>.</p>
</section>
</body>
</html>
