-- Modify Users table
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    session_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Questions table
CREATE TABLE questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    level ENUM('Beginner','Intermediate','Advanced','Master') NOT NULL,
    question TEXT NOT NULL,
    option_a VARCHAR(255) NOT NULL,
    option_b VARCHAR(255) NOT NULL,
    option_c VARCHAR(255) NOT NULL,
    option_d VARCHAR(255) NOT NULL,
    correct_option CHAR(1) NOT NULL
);

-- Results table
CREATE TABLE results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    level ENUM('Beginner','Intermediate','Advanced','Master') NOT NULL,
    score INT NOT NULL,
    total INT NOT NULL,
    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Create User Answers table
CREATE TABLE user_answers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    result_id INT NOT NULL,
    question_id INT NOT NULL,
    selected_option CHAR(1) NOT NULL,
    FOREIGN KEY (result_id) REFERENCES results(id),
    FOREIGN KEY (question_id) REFERENCES questions(id)
);

-- Sample questions for Beginner level
INSERT INTO questions (level, question, option_a, option_b, option_c, option_d, correct_option) VALUES
('Beginner', 'What is the capital of France?', 'Berlin', 'London', 'Paris', 'Rome', 'C'),
('Beginner', 'Which planet is known as the Red Planet?', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'B'),
('Beginner', 'What is 2 + 2?', '3', '4', '5', '6', 'B'),
('Beginner', 'Which animal barks?', 'Cat', 'Dog', 'Cow', 'Sheep', 'B'),
('Beginner', 'What color is the sky on a clear day?', 'Blue', 'Green', 'Red', 'Yellow', 'A'),
('Beginner', 'Which is a fruit?', 'Carrot', 'Potato', 'Apple', 'Lettuce', 'C'),
('Beginner', 'How many days in a week?', '5', '6', '7', '8', 'C'),
('Beginner', 'What do bees make?', 'Milk', 'Honey', 'Bread', 'Cheese', 'B'),
('Beginner', 'Which is a primary color?', 'Purple', 'Orange', 'Red', 'Pink', 'C'),
('Beginner', 'What is H2O?', 'Oxygen', 'Hydrogen', 'Water', 'Salt', 'C'),
('Beginner', 'Which is a mammal?', 'Shark', 'Dolphin', 'Crocodile', 'Eagle', 'B'),
('Beginner', 'Which is a vegetable?', 'Banana', 'Tomato', 'Potato', 'Apple', 'C'),
('Beginner', 'What is the opposite of hot?', 'Warm', 'Cold', 'Cool', 'Boiling', 'B'),
('Beginner', 'Which is a mode of transport?', 'Bicycle', 'Spoon', 'Chair', 'Table', 'A'),
('Beginner', 'What is the largest continent?', 'Africa', 'Asia', 'Europe', 'Australia', 'B'),
('Beginner', 'Which is a bird?', 'Lion', 'Tiger', 'Sparrow', 'Wolf', 'C'),
('Beginner', 'What is the color of grass?', 'Blue', 'Green', 'Red', 'Black', 'B'),
('Beginner', 'Which is a domestic animal?', 'Tiger', 'Cow', 'Lion', 'Wolf', 'B'),
('Beginner', 'What do you use to write?', 'Spoon', 'Pen', 'Plate', 'Cup', 'B'),
('Beginner', 'Which is a shape?', 'Circle', 'Tree', 'Car', 'House', 'A');

-- Sample questions for Intermediate level
INSERT INTO questions (level, question, option_a, option_b, option_c, option_d, correct_option) VALUES
('Intermediate', 'What is the chemical symbol for Gold?', 'Au', 'Ag', 'Gd', 'Go', 'A'),
('Intermediate', 'Who wrote "Romeo and Juliet"?', 'Charles Dickens', 'William Shakespeare', 'Jane Austen', 'Mark Twain', 'B'),
('Intermediate', 'What is the largest ocean?', 'Atlantic', 'Indian', 'Arctic', 'Pacific', 'D'),
('Intermediate', 'Which country hosted the 2016 Summer Olympics?', 'China', 'Brazil', 'UK', 'Russia', 'B'),
('Intermediate', 'What is the square root of 81?', '7', '8', '9', '10', 'C'),
('Intermediate', 'Who painted the Mona Lisa?', 'Van Gogh', 'Da Vinci', 'Picasso', 'Rembrandt', 'B'),
('Intermediate', 'Which gas do plants absorb?', 'Oxygen', 'Carbon Dioxide', 'Nitrogen', 'Hydrogen', 'B'),
('Intermediate', 'What is the capital of Canada?', 'Toronto', 'Vancouver', 'Ottawa', 'Montreal', 'C'),
('Intermediate', 'Which planet has rings?', 'Mars', 'Venus', 'Saturn', 'Mercury', 'C'),
('Intermediate', 'Who discovered gravity?', 'Newton', 'Einstein', 'Galileo', 'Tesla', 'A'),
('Intermediate', 'What is the freezing point of water?', '0°C', '32°C', '100°C', '212°C', 'A'),
('Intermediate', 'Which is the smallest prime number?', '0', '1', '2', '3', 'C'),
('Intermediate', 'What is the main language in Brazil?', 'Spanish', 'Portuguese', 'French', 'English', 'B'),
('Intermediate', 'Which continent is Egypt in?', 'Asia', 'Europe', 'Africa', 'Australia', 'C'),
('Intermediate', 'What is the hardest natural substance?', 'Gold', 'Iron', 'Diamond', 'Silver', 'C'),
('Intermediate', 'Who invented the telephone?', 'Edison', 'Bell', 'Tesla', 'Newton', 'B'),
('Intermediate', 'What is the boiling point of water?', '50°C', '100°C', '150°C', '200°C', 'B'),
('Intermediate', 'Which is a leap year?', '2018', '2019', '2020', '2021', 'C'),
('Intermediate', 'Which is not a primary color?', 'Red', 'Blue', 'Green', 'Yellow', 'C'),
('Intermediate', 'Who is known as the father of computers?', 'Charles Babbage', 'Alan Turing', 'Bill Gates', 'Steve Jobs', 'A');

-- Sample questions for Advanced level
INSERT INTO questions (level, question, option_a, option_b, option_c, option_d, correct_option) VALUES
('Advanced', 'What is the powerhouse of the cell?', 'Nucleus', 'Mitochondria', 'Ribosome', 'Chloroplast', 'B'),
('Advanced', 'Who developed the theory of relativity?', 'Newton', 'Einstein', 'Curie', 'Bohr', 'B'),
('Advanced', 'What is the capital of Norway?', 'Stockholm', 'Copenhagen', 'Oslo', 'Helsinki', 'C'),
('Advanced', 'Which element has atomic number 6?', 'Oxygen', 'Nitrogen', 'Carbon', 'Helium', 'C'),
('Advanced', 'What is the largest desert?', 'Sahara', 'Gobi', 'Kalahari', 'Arctic', 'A'),
('Advanced', 'Who wrote "1984"?', 'Orwell', 'Huxley', 'Bradbury', 'Atwood', 'A'),
('Advanced', 'What is the value of pi (to 2 decimal places)?', '3.12', '3.14', '3.16', '3.18', 'B'),
('Advanced', 'Which is not a programming language?', 'Python', 'Ruby', 'HTML', 'Java', 'C'),
('Advanced', 'What is the longest river?', 'Amazon', 'Nile', 'Yangtze', 'Mississippi', 'B'),
('Advanced', 'Who painted "Starry Night"?', 'Monet', 'Van Gogh', 'Da Vinci', 'Picasso', 'B'),
('Advanced', 'What is the main gas in the air?', 'Oxygen', 'Carbon Dioxide', 'Nitrogen', 'Hydrogen', 'C'),
('Advanced', 'Which planet is closest to the sun?', 'Venus', 'Mercury', 'Earth', 'Mars', 'B'),
('Advanced', 'What is the currency of Japan?', 'Yen', 'Won', 'Dollar', 'Euro', 'A'),
('Advanced', 'Who discovered penicillin?', 'Fleming', 'Pasteur', 'Lister', 'Salk', 'A'),
('Advanced', 'Which is not a mammal?', 'Bat', 'Dolphin', 'Shark', 'Whale', 'C'),
('Advanced', 'What is the speed of light?', '300,000 km/s', '150,000 km/s', '1,000 km/s', '30,000 km/s', 'A'),
('Advanced', 'Who is the Greek god of the sea?', 'Zeus', 'Poseidon', 'Hades', 'Apollo', 'B'),
('Advanced', 'What is the chemical formula for table salt?', 'NaCl', 'KCl', 'CaCl2', 'MgCl2', 'A'),
('Advanced', 'Which country is known as the Land of the Rising Sun?', 'China', 'Japan', 'Thailand', 'Vietnam', 'B'),
('Advanced', 'What is the largest bone in the human body?', 'Femur', 'Tibia', 'Humerus', 'Skull', 'A');

-- Sample questions for Master level
INSERT INTO questions (level, question, option_a, option_b, option_c, option_d, correct_option) VALUES
('Master', 'What is Schrödinger’s cat an example of?', 'Genetics', 'Quantum Superposition', 'Evolution', 'Relativity', 'B'),
('Master', 'Who formulated the laws of motion?', 'Einstein', 'Newton', 'Galileo', 'Kepler', 'B'),
('Master', 'What is the derivative of sin(x)?', 'cos(x)', '-cos(x)', 'sin(x)', '-sin(x)', 'A'),
('Master', 'Which is the heaviest naturally occurring element?', 'Uranium', 'Plutonium', 'Lead', 'Gold', 'A'),
('Master', 'What is the capital of Iceland?', 'Oslo', 'Copenhagen', 'Reykjavik', 'Helsinki', 'C'),
('Master', 'Who wrote "The Republic"?', 'Plato', 'Aristotle', 'Socrates', 'Homer', 'A'),
('Master', 'What is the integral of 1/x dx?', 'ln(x)', 'x', 'e^x', '1/x', 'A'),
('Master', 'Which scientist is known for the uncertainty principle?', 'Heisenberg', 'Bohr', 'Planck', 'Fermi', 'A'),
('Master', 'What is the capital of New Zealand?', 'Sydney', 'Auckland', 'Wellington', 'Christchurch', 'C'),
('Master', 'Who developed the polio vaccine?', 'Salk', 'Fleming', 'Pasteur', 'Jenner', 'A'),
('Master', 'What is the smallest unit of matter?', 'Atom', 'Molecule', 'Electron', 'Proton', 'A'),
('Master', 'Which is not a noble gas?', 'Helium', 'Neon', 'Oxygen', 'Argon', 'C'),
('Master', 'What is the value of Planck’s constant?', '6.63e-34 Js', '3.00e8 m/s', '1.60e-19 C', '9.81 m/s^2', 'A'),
('Master', 'Who is the author of "War and Peace"?', 'Tolstoy', 'Dostoevsky', 'Pushkin', 'Chekhov', 'A'),
('Master', 'What is the capital of Mongolia?', 'Ulaanbaatar', 'Astana', 'Tashkent', 'Bishkek', 'A'),
('Master', 'What is the SI unit of electric current?', 'Volt', 'Ampere', 'Ohm', 'Watt', 'B'),
('Master', 'Who discovered radioactivity?', 'Curie', 'Rutherford', 'Becquerel', 'Fermi', 'C'),
('Master', 'What is the chemical formula for glucose?', 'C6H12O6', 'C12H22O11', 'C2H5OH', 'CH4', 'A'),
('Master', 'Which is the largest moon of Saturn?', 'Europa', 'Titan', 'Ganymede', 'Callisto', 'B'),
('Master', 'What is the main component of the sun?', 'Oxygen', 'Hydrogen', 'Carbon', 'Helium', 'B');
