<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About - QuizApp</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'navbar.php'; ?>
<section class="content">
    <h2>About QuizApp</h2>
    <p>QuizApp is a fun and interactive platform to test your knowledge across various topics and difficulty levels. Built with PHP, MySQL, HTML, CSS, and JavaScript.</p>
</section>
</body>
</html>
