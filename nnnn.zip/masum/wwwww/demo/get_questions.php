<?php
require_once 'config.php';
require_once 'classes/QuestionBank.php';

header('Content-Type: application/json');

try {
    $level = isset($_GET['level']) ? (int)$_GET['level'] : 1;
    $count = isset($_GET['count']) ? (int)$_GET['count'] : 20;

    $questionBank = new QuestionBank($pdo);
    $questions = $questionBank->getRandomQuestions($level, $count);

    echo json_encode([
        'success' => true,
        'questions' => $questions
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
