// Add hover/click effects for level cards
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.level-card').forEach(function(card) {
        card.addEventListener('mousedown', function() {
            card.style.transform = 'scale(0.97)';
        });
        card.addEventListener('mouseup', function() {
            card.style.transform = '';
        });
        card.addEventListener('mouseleave', function() {
            card.style.transform = '';
        });
    });
});